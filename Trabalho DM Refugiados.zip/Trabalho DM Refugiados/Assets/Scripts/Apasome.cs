﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;

public class Apasome : MonoBehaviour {

    public GameObject Panel1;
    public GameObject Panel2;
    public GameObject Painel3;
    private bool _isEndOfDialogue = false;

    //public GameObject Botao;

    public void EscondePainel()
    {
        Panel1.SetActive(true);
        Panel2.SetActive(false);
       
    
        if (_isEndOfDialogue)
        {
            Painel3.SetActive(true);
        }
    

    //Botao.GetComponent<Button>().interactable = true;
}

}
