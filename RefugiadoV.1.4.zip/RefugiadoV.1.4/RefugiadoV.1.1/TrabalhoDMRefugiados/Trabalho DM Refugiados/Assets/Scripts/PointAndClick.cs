﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PointAndClick : MonoBehaviour {

    private void OnMouseDown()
    {
        switch (gameObject.tag)
        {
            case "Cena_Ida": cenaIda(); break;
            case "Cena_Volta": CenaVolta(); break;
        }
    }

    void cenaIda()
    {
        if(this.gameObject.name == "Cena_1")
        {
            SceneManager.LoadScene("Cena_1");
        }
        if(this.gameObject.name == "Cena_2")
        {
            SceneManager.LoadScene("Cena_2");
        }
        if (this.gameObject.name == "Cena_3")
        {
            SceneManager.LoadScene("Cena_3");
        }
        if (this.gameObject.name == "Cena_4")
        {
            SceneManager.LoadScene("Cena_4");
        }
        if (this.gameObject.name == "Cena_5")
        {
            SceneManager.LoadScene("Cena_5");
        }
        if (this.gameObject.name == "Cena_6")
        {
            SceneManager.LoadScene("Cena_6");
        }
    }

    void CenaVolta()
    {
        if(this. gameObject.name == "Inicio_1")
        {
            SceneManager.LoadScene("Inicio");
        }
        if (this.gameObject.name == "Inicio_2")
        {
            SceneManager.LoadScene("Inicio");
        }
        if (this.gameObject.name == "Inicio_3")
        {
            SceneManager.LoadScene("Inicio");
        }
        if (this.gameObject.name == "Inicio_4")
        {
            SceneManager.LoadScene("Inicio");
        }
        if (this.gameObject.name == "Inicio_5")
        {
            SceneManager.LoadScene("Inicio");
        }
        if (this.gameObject.name == "Inicio_6")
        {
            SceneManager.LoadScene("Inicio");
        }

    }
 
}
