﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class ButtonDia : MonoBehaviour {

	// Use this for initialization
	public void Clica () {
        SceneManager.LoadScene("TeladeTextos");
    }
	
}
